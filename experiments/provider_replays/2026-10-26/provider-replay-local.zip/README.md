# Local provider replay, 2026-10-26

Synthetic Fenko browser and Proton WASM reports, exact project runner snapshots, selected pinned Fenko source, and dependency locks. Run python verify.py after extraction with the project Python dependencies. The verifier checks hashes, 40 Fenko signatures, 18 Fenko PRF witness links, 12 Proton signatures and 12 Proton PRF digest relationships. It does not independently attest local execution or provider private state.

Fenko source commit: 2d873fbe25257250de6e322e9d785b97b17a544f. Proton source commit: 69a0927f0fe7071243d6c38e404459a69210fdd4. The Proton worker WASM is omitted; npm ci with the pinned lockfile restores it for an executable rerun. Browser profiles, vaults, keys, HMAC seeds, raw PRF outputs, and plaintext CXF are not retained.
